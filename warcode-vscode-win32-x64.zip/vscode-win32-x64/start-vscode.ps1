param([int]$Port = 4096)

$ErrorActionPreference = 'Stop'
$runtime = Get-Process -Name Code -ErrorAction SilentlyContinue |
  Where-Object Path |
  Select-Object -First 1 -ExpandProperty Path

if (-not $runtime) {
  $runtime = @(
    "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe"
    "$env:ProgramFiles\Microsoft VS Code\Code.exe"
  ) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
if (-not $runtime) { throw 'Open VS Code, then run this script again.' }

$env:ELECTRON_RUN_AS_NODE = '1'
$env:WARCODE_FLAGS = (@($env:WARCODE_FLAGS, 'builtin_mcp') | Where-Object { $_ }) -join ','
if (-not $env:WARCODE_PASSWORD) { $env:WARCODE_PASSWORD = [guid]::NewGuid().ToString('N') }
Write-Host "Server link: http://localhost:$Port"
Write-Host "Password: $env:WARCODE_PASSWORD"
Write-Host 'Open the server link after startup. Press Ctrl+C to stop.'
& $runtime --use-system-ca (Join-Path $PSScriptRoot 'warcode.mjs') serve --port $Port | Out-Host
exit $LASTEXITCODE
