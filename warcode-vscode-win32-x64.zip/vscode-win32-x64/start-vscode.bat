@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-vscode.ps1" %*
set "WARCODE_EXIT_CODE=%errorlevel%"
echo.
if not "%WARCODE_EXIT_CODE%"=="0" echo Warcode exited with error code %WARCODE_EXIT_CODE%. See the message above.
pause
exit /b %WARCODE_EXIT_CODE%
