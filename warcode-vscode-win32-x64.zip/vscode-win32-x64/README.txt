Portable browser app through VS Code (Windows)

This package runs a local server through VS Code. It cannot run on a browser-only
computer that blocks executable processes. On that computer, use a browser to
connect to a separately hosted app server. Model inference must also run on the
server or through a configured cloud provider; no local model engine is bundled.

Copy this entire folder, including assets, to another computer of the same
architecture. Bun, npm and npx are not needed to run the packaged MCP servers.

Double-click start-vscode.bat, or run it from a terminal:
  .\start-vscode.bat

Then open http://localhost:4096 in your browser. Keep the terminal running.
The terminal displays the server link and password. Each launch generates a new
password unless WARCODE_PASSWORD is already set in the environment.
If startup fails or the server stops, the BAT window stays open until you press a key.
Use .\start-vscode.bat -Port 4097 to select another port.
The BAT launcher calls start-vscode.ps1 with a process-local execution-policy bypass.

The launcher enables the builtin_mcp feature flag. The packaged servers start
disabled; enable them in the app when wanted. Existing explicit MCP configuration
takes precedence over these presets, including older commands that use npx.

Open Computer Use is included as a native server. Its original license and
third-party notices are under assets/mcp/open-computer-use.

Palantir is included only when the private @palantir/mcp package was supplied at
build time. The public palantir-mcp package is a downloader, not the actual server.
Foundry credentials are still required at runtime and are not embedded.

To build with both servers, run from the repository root:
  $env:WARCODE_PALANTIR_MCP_PACKAGE = 'C:\path\to\palantir-mcp.tgz'
  bun run --cwd packages/cli build:node --bundle-only

Use the actual private @palantir/mcp tarball from your Foundry registry, not the
public palantir-mcp package. Its runtime dependencies must be available to Bun
during the build. Install scripts are disabled. Native dependencies, if present,
must match the target OS/architecture and be compatible with VS Code's runtime.
